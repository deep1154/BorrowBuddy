# BorrowBuddy – Campus Lending & Return Tracker

MAD mini-project for Meet Kevadiya (12302130601039), CSD, ADIT.

## What it does
- Add a lending record with item, borrower, contact, category, notes and due date.
- View active, overdue and returned records; filter and search.
- Mark a loan returned; delete with confirmation.
- Dashboard counts; offline local persistence via shared_preferences.
- Works in Flutter Chrome and Android. No backend, account, internet or camera needed.

## Run on Windows
1. Install Flutter and Chrome (already configured if `flutter doctor` is healthy).
2. Extract ZIP and open CMD in the folder containing `pubspec.yaml`.
3. Run:

```cmd
flutter create . --platforms android,web
flutter pub get
flutter run -d chrome
```

To run on an attached Android phone:

```cmd
flutter devices
flutter run -d YOUR_DEVICE_ID
```

## Demo
1. Add 'Data Structures Book', borrower 'Rahul', category Books, due tomorrow.
2. Search for Rahul and show the Active filter.
3. Mark the loan Returned and show the Returned filter and dashboard.
4. Reload the app and show that records remain saved.
5. Add a loan with a past due date to demonstrate Overdue status.

## Important limitations
- This is a single-device offline prototype. Data is saved per browser/device; it does not sync across devices.
- Due dates are shown in the app; no push notifications are sent.
- There is no user authentication or QR scanning.
- If the browser storage is cleared or app data removed, local records may be lost.

## Technical note
The ZIP includes complete Dart app source and pubspec.yaml. `flutter create .` generates platform folders. No Flutter SDK is available in the generation environment, so actual compilation on your PC remains the final verification step.
