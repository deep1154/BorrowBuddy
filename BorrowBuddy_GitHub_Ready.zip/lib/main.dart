import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const BorrowBuddyApp()); }

class Loan {
  final String id, item, person, contact, notes, category;
  final DateTime lentOn, dueOn;
  final DateTime? returnedOn;
  const Loan({required this.id, required this.item, required this.person,
    required this.contact, required this.notes, required this.category,
    required this.lentOn, required this.dueOn, this.returnedOn});
  bool get returned => returnedOn != null;
  bool get overdue => !returned && dueOn.isBefore(DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day));
  Map<String, dynamic> toJson() => {'id':id,'item':item,'person':person,'contact':contact,'notes':notes,
    'category':category,'lentOn':lentOn.toIso8601String(),'dueOn':dueOn.toIso8601String(),
    'returnedOn':returnedOn?.toIso8601String()};
  factory Loan.fromJson(Map<String,dynamic> j) => Loan(id:j['id'] as String,
    item:j['item'] as String, person:j['person'] as String,
    contact:(j['contact']??'') as String, notes:(j['notes']??'') as String,
    category:(j['category']??'Other') as String,
    lentOn:DateTime.parse(j['lentOn'] as String), dueOn:DateTime.parse(j['dueOn'] as String),
    returnedOn:j['returnedOn']==null?null:DateTime.parse(j['returnedOn'] as String));
  Loan copyWith({DateTime? returnedAt}) => Loan(id:id,item:item,person:person,contact:contact,
    notes:notes,category:category,lentOn:lentOn,dueOn:dueOn,returnedOn:returnedAt);
}

String dateText(DateTime d) => '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year}';

class BorrowBuddyApp extends StatelessWidget {
  const BorrowBuddyApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(title:'BorrowBuddy',debugShowCheckedModeBanner:false,
    theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF3455D1)),
      scaffoldBackgroundColor:const Color(0xFFF5F7FC),appBarTheme:const AppBarTheme(backgroundColor:Color(0xFFF5F7FC))),
    home:const HomePage());
}

class HomePage extends StatefulWidget {const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState();}
class _HomePageState extends State<HomePage> {
  final List<Loan> _loans=[];
  bool _loading=true;
  String _query='',_filter='All';
  @override void initState(){super.initState();_load();}
  Future<void> _load() async {
    try { final p=await SharedPreferences.getInstance();
      final raw=p.getString('borrowbuddy_loans_v1');
      if(raw!=null){final decoded=jsonDecode(raw) as List<dynamic>;
        _loans.addAll(decoded.map((e)=>Loan.fromJson(Map<String,dynamic>.from(e as Map))));}
    } catch (_) { if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Saved records could not be loaded.')));} }
    if(mounted)setState(()=>_loading=false);
  }
  Future<void> _save() async { final p=await SharedPreferences.getInstance();
    await p.setString('borrowbuddy_loans_v1',jsonEncode(_loans.map((e)=>e.toJson()).toList())); }
  Future<void> _add() async {
    final result=await showDialog<Loan>(context:context,builder:(context)=>const AddLoanDialog());
    if(result==null)return;
    setState(()=>_loans.insert(0,result));await _save();
  }
  Future<void> _markReturned(Loan loan) async {
    final idx=_loans.indexWhere((e)=>e.id==loan.id);if(idx<0)return;
    setState(()=>_loans[idx]=loan.copyWith(returnedAt:DateTime.now()));await _save();
  }
  Future<void> _delete(Loan loan) async {
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Delete record?'),
      content:Text('Remove ${loan.item} lent to ${loan.person}?'),actions:[
      TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),
      FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Delete'))]));
    if(ok!=true)return;
    setState(()=>_loans.removeWhere((e)=>e.id==loan.id));await _save();
  }
  List<Loan> get _visible {
    final q=_query.toLowerCase().trim();
    final items=_loans.where((l){
      final match=q.isEmpty||'${l.item} ${l.person} ${l.category} ${l.contact}'.toLowerCase().contains(q);
      final status=_filter=='All'||(_filter=='Active'&&!l.returned)||(_filter=='Overdue'&&l.overdue)||(_filter=='Returned'&&l.returned);
      return match&&status;
    }).toList();
    items.sort((a,b)=>b.lentOn.compareTo(a.lentOn));return items;
  }
  @override Widget build(BuildContext context) {
    final active=_loans.where((e)=>!e.returned).length;
    final overdue=_loans.where((e)=>e.overdue).length;
    final returned=_loans.where((e)=>e.returned).length;
    return Scaffold(appBar:AppBar(title:const Row(children:[Icon(Icons.handshake_outlined),SizedBox(width:10),Text('BorrowBuddy',style:TextStyle(fontWeight:FontWeight.bold))])),
      floatingActionButton:FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.add),label:const Text('New Loan')),
      body:_loading?const Center(child:CircularProgressIndicator()):SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:900),child:
        ListView(padding:const EdgeInsets.fromLTRB(16,8,16,96),children:[
          const Text('Campus lending, made simple.',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
          const SizedBox(height:5),const Text('Remember who borrowed your things and when they are due.'),
          const SizedBox(height:18),Row(children:[_stat('Active',active,Icons.inventory_2_outlined),const SizedBox(width:8),
            _stat('Overdue',overdue,Icons.warning_amber_rounded),const SizedBox(width:8),_stat('Returned',returned,Icons.task_alt)]),
          const SizedBox(height:22),TextField(onChanged:(v)=>setState(()=>_query=v),decoration:InputDecoration(
            hintText:'Search item, borrower or category',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,
            border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))),
          const SizedBox(height:12),SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:
            ['All','Active','Overdue','Returned'].map((v)=>Padding(padding:const EdgeInsets.only(right:8),child:
              ChoiceChip(label:Text(v),selected:_filter==v,onSelected:(_)=>setState(()=>_filter=v)))).toList())),
          const SizedBox(height:12),Text('${_visible.length} records',style:const TextStyle(color:Colors.black54)),
          const SizedBox(height:8),if(_visible.isEmpty)Card(child:Padding(padding:const EdgeInsets.all(28),child:
            Column(children:[const Icon(Icons.inventory_2_outlined,size:50,color:Colors.blueGrey),const SizedBox(height:10),
              const Text('No matching loans yet'),const SizedBox(height:8),TextButton(onPressed:_add,child:const Text('Add your first loan'))])))
          else ..._visible.map(_loanCard),
        ])))));
  }
  Widget _stat(String label,int count,IconData icon)=>Expanded(child:Card(color:Colors.white,child:Padding(padding:const EdgeInsets.symmetric(vertical:15,horizontal:8),child:
    Column(children:[Icon(icon,color:const Color(0xFF3455D1)),const SizedBox(height:5),Text('$count',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
      Text(label,style:const TextStyle(fontSize:12))]))));
  Widget _loanCard(Loan l) {
    final status=l.returned?'Returned':l.overdue?'Overdue':'Active';
    final statusColor=l.returned?Colors.green:l.overdue?Colors.red:Colors.indigo;
    return Card(color:Colors.white,margin:const EdgeInsets.only(bottom:10),child:Padding(padding:const EdgeInsets.all(14),child:
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[CircleAvatar(child:Icon(_icon(l.category))),const SizedBox(width:12),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(l.item,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
            Text('Borrower: ${l.person}')])) ,Chip(label:Text(status,style:TextStyle(color:statusColor,fontSize:12)),backgroundColor:statusColor.withValues(alpha:.09),side:BorderSide.none)]),
        const SizedBox(height:8),Text('${l.category}  •  Lent: ${dateText(l.lentOn)}  •  Due: ${dateText(l.dueOn)}'),
        if(l.contact.isNotEmpty)Text('Contact: ${l.contact}'),
        if(l.notes.isNotEmpty)Text('Note: ${l.notes}'),
        if(l.returned)Text('Returned: ${dateText(l.returnedOn!)}',style:const TextStyle(color:Colors.green)),
        const Divider(),Row(children:[if(!l.returned)TextButton.icon(onPressed:()=>_markReturned(l),icon:const Icon(Icons.check_circle_outline),label:const Text('Mark Returned')),
          const Spacer(),IconButton(onPressed:()=>_delete(l),icon:const Icon(Icons.delete_outline),tooltip:'Delete record')])
      ])));
  }
  IconData _icon(String c){switch(c){case 'Books':return Icons.menu_book;case 'Electronics':return Icons.devices;case 'Stationery':return Icons.edit_note;case 'Sports':return Icons.sports_basketball;default:return Icons.category;}}
}

class AddLoanDialog extends StatefulWidget {const AddLoanDialog({super.key});@override State<AddLoanDialog> createState()=>_AddLoanDialogState();}
class _AddLoanDialogState extends State<AddLoanDialog> {
  final _key=GlobalKey<FormState>();
  final _item=TextEditingController(),_person=TextEditingController(),_contact=TextEditingController(),_notes=TextEditingController();
  String _category='Books';DateTime _due=DateTime.now().add(const Duration(days:7));
  @override void dispose(){_item.dispose();_person.dispose();_contact.dispose();_notes.dispose();super.dispose();}
  Future<void> _pickDate() async {final d=await showDatePicker(context:context,initialDate:_due,
    firstDate:DateTime.now().subtract(const Duration(days:365)),lastDate:DateTime.now().add(const Duration(days:3650)));
    if(d!=null)setState(()=>_due=d);}
  @override Widget build(BuildContext context)=>AlertDialog(title:const Text('New lending record'),
    content:SizedBox(width:440,child:SingleChildScrollView(child:Form(key:_key,child:Column(mainAxisSize:MainAxisSize.min,children:[
      TextFormField(controller:_item,decoration:const InputDecoration(labelText:'Item name *'),validator:(v)=>v==null||v.trim().isEmpty?'Enter item name':null),
      TextFormField(controller:_person,decoration:const InputDecoration(labelText:'Borrower name *'),validator:(v)=>v==null||v.trim().isEmpty?'Enter borrower name':null),
      TextFormField(controller:_contact,decoration:const InputDecoration(labelText:'Contact (optional)')),
      DropdownButtonFormField<String>(value:_category,decoration:const InputDecoration(labelText:'Category'),
        items:['Books','Electronics','Stationery','Sports','Other'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
        onChanged:(v)=>setState(()=>_category=v??'Other')),
      TextFormField(controller:_notes,decoration:const InputDecoration(labelText:'Notes (optional)')),
      const SizedBox(height:10),ListTile(contentPadding:EdgeInsets.zero,title:const Text('Return due date'),subtitle:Text(dateText(_due)),
        trailing:const Icon(Icons.calendar_month),onTap:_pickDate),
    ])))),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),
      FilledButton(onPressed:(){if(!_key.currentState!.validate())return;
        Navigator.pop(context,Loan(id:DateTime.now().microsecondsSinceEpoch.toString(),item:_item.text.trim(),
          person:_person.text.trim(),contact:_contact.text.trim(),notes:_notes.text.trim(),category:_category,
          lentOn:DateTime.now(),dueOn:_due));},child:const Text('Save Loan'))]);
}
